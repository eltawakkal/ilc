<?php
	$this->load->view('template/header');
	$this->load->view($body);
	$this->load->view('template/footer');
?>